<?php
require("../../conexionbd/conexionbase.php");
require("../../conexionbd/conexionestelar.php");
require("../../includes/account.php");

mysql_select_db($database_conexionestelar,$conexionestelar);

$contractor=isset($_POST['name_contractor'])?$_POST['name_contractor']:NULL;
$name=isset($_POST['name'])?$_POST['name']:NULL;
$email=isset($_POST['email'])?$_POST['email']:NULL;
$position=isset($_POST['position'])?$_POST['position']:NULL;

if($contractor)
{
	mysql_query("insert into contratistas(nombre,fecharegistro,horaregistro,activo) values('".strtoupper($contractor)."','".date('Y-m-d')."','".date('H:i:s')."','1')",$conexionestelar) or die(mysql_error());
	$idcontractor=mysql_insert_id();
	foreach($name as $key=>$valor)
	{ //echo $valor." ".$email[$key]." ".$position[$key]."<br>";
		mysql_query("insert into contratistas_contactos(idcontratista,name,email,position,activo) values('".$idcontractor."','".$valor."','".$email[$key]."','".$position[$key]."','1')",$conexionestelar) or die(mysql_error());
	}

}
mysql_close($conexionestelar);
echo "<script>location.href='../new_contratist.php'</script>";

?>