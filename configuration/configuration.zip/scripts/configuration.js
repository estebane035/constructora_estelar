// JavaScript Document
//new_contratis.php
var cf=1;
function agregar_contacto()
{
	tabla = document.getElementById('table_contacts'); 
	tr = tabla.insertRow(tabla.rows.length);  //agrega la fila
	td = tr.insertCell(tr.cells.length);   //agrega la columna
		td.innerHTML = "<input type='text' name='name[]'>"; //agrega valor a la columna
	td = tr.insertCell(tr.cells.length); 
		td.innerHTML = "<input type='text' name='email[]'>"; 
	td = tr.insertCell(tr.cells.length);
		td.innerHTML = "<input type='text' name='position[]'>";
}

//new_contratist.php
function save_new_contratist()
{ document.new_contratist_form.submit();
}
//new_constructor.php
function save_new_constructor()
{ document.new_constructor_form.submit();
}

//user_new.php
function save_new_user()
{ document.new_user_form.submit();
}
//new_work.php
function save_new_work()
{ document.new_work_form.submit();
}