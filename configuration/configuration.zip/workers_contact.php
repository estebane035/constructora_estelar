<?php
//NEW CONTRATIST
include("../conexionbd/conexionbase.php");
include("../conexionbd/conexionestelar.php");
require("../includes/account.php");

mysql_select_db($database_conexionestelar,$conexionestelar);
//OBTIENE LISTA DE TRABAJADORES
	$workers=mysql_query("select idusuario,nombre from vista_trabajadores",$conexionestelar) or die(mysql_error());
	$row_workers=mysql_fetch_assoc($workers);

?>
<!DOCTYPE>
<html>
<head>
<meta charset="iso-8859-1" />
<title>Worker Contact</title>
<link href="../css/estelar.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div id="header">
    	<?php include("../includes/header.php");?>
    </div>
    <div style="clear:both"></div>
    <div id="central">
		<table>
        	<tr><td class="titulopagina">Worker Contact</td></tr>
		</table><br><br>
		<table id="tablapadding5center">
        	<thead><th>Worker</th><th>Telephone</th><th>Email</th></thead>
            <tbody>
            	<?php 
				do{
					$contacto=mysql_query("select telefono,email from worker_contact where idworker='".$row_workers['idusuario']."' and activo=1 limit 0,1",$conexionestelar) or die(mysql_error());
					$row_contacto=mysql_fetch_assoc($contacto);
					?>
            	<tr>
                	<td><?php echo $row_workers['nombre']?></td>
                    <td id="<?php echo "telephone".$row_workers['idusuario']?>"><input type="text" value="<?php echo $row_contacto['telefono']?>" onBlur="actualiza_telefono(<?php echo $row_workers['idusuario']?>)" id="<?php echo "valor_telephone".$row_workers['idusuario']?>"></td></td>
                    <td id="<?php echo "email".$row_workers['idusuario']?>"><input type="text" value="<?php echo $row_contacto['email']?>" onBlur="actualiza_email(<?php echo $row_workers['idusuario']?>)" id="<?php echo "valor_email".$row_workers['idusuario']?>"></td>
            	</tr>
                <?php }while($row_workers=mysql_fetch_assoc($workers));?>
            </tbody>
        </table>
    </div><!--div central-->
    <div style="clear:both"></div>
  </div> <!--div holder-->    

</body>
<script type="text/javascript" src="scripts/configuration.js"></script>
<script type="text/javascript" src="scripts/configuration_ajax.js"></script>
</html>